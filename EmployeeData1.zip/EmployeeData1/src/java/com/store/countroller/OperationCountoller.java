package com.store.countroller;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import com.store.entities.Employees;
import com.store.repos.EmployeeRepo;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author ELnour
 */
public class OperationCountoller extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
      
    
    {
        
        String page = request.getParameter("page");
        String opertion = request.getParameter("opertion");
        if (page == null || page.equals("") || opertion == null || opertion.equals("")) {
            response.sendRedirect("index.html");
        } else {
           if (opertion.equals("login")) {

                
               
                }else if (opertion.equals("insertNewEmployee"))
            {
                String id = request.getParameter("ID");
                String fname = request.getParameter("fName");
                String lname = request.getParameter("lname");
                String salary = request.getParameter("salary");
                String jop = request.getParameter("jop");
                String Addrees = request.getParameter("address");
                String phone = request.getParameter("phone");
              
              Employees employee = new    Employees();
                employee.setId(Integer.parseInt(id));
                employee.setFname(fname);
                employee.setLname(lname);
                employee.setSalary(Integer.parseInt( salary));
                employee.setEmpjop(jop);
                employee.setAddress(Addrees);
                employee.setPhone(Integer.parseInt(phone));
                EmployeeRepo repo = new EmployeeRepo();
                repo.insert(employee);
                
            }else if(opertion.equals("updateEmployee")){
                String id = request.getParameter("ID");
                String fname = request.getParameter("fName");
                String lname = request.getParameter("lname");
                String salary = request.getParameter("salary");
                String jop = request.getParameter("jop");
                String Addrees = request.getParameter("address");
                String phone = request.getParameter("phone");
              
               
               Employees employee = new  Employees();
                employee.setId(Integer.parseInt(id));
                employee.setFname(fname);
                employee.setLname(lname);
                employee.setSalary(Integer.parseInt( salary));
                employee.setEmpjop(jop);
                employee.setAddress(Addrees);
                employee.setPhone(Integer.parseInt(phone));
                
                EmployeeRepo repo = new EmployeeRepo();
                repo.update(employee,Integer.parseInt(id));
                
            }else if (opertion.equals("insertNewEmployee"))
            {
                String employeeid = request.getParameter("ID");
                String fname = request.getParameter("fName");
                String lname = request.getParameter("lname");
                String salary = request.getParameter("salary");
                String jop = request.getParameter("jop");
                String Addrees = request.getParameter("address");
                String phone = request.getParameter("phone");
              
              Employees employee = new    Employees();
                employee.setId(Integer.parseInt(employeeid));
                employee.setFname(fname);
                employee.setLname(lname);
                employee.setSalary(Integer.parseInt( salary));
                employee.setEmpjop(jop);
                employee.setAddress(Addrees);
                employee.setPhone(Integer.parseInt(phone));
                EmployeeRepo repo = new EmployeeRepo();
                repo.insert(employee);
               
            }        else if (opertion.equals("DeleteEmployee")) {
                    String employeeid = request.getParameter("id");
                   EmployeeRepo repo = new EmployeeRepo();
                   repo.delete(Integer.parseInt(employeeid));
                 
            }
            request.getRequestDispatcher("menuAppCountoller?page=" + page).forward(request, response);
        }
    
        
    }
    }
    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
